
service MapReduceService {
	bool ping(),
	string getSentinment(1: string filenames)
}
