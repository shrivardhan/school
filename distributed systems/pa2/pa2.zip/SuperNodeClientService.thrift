service SuperNodeClientService {
	bool ping(),
  string getNode()
}
